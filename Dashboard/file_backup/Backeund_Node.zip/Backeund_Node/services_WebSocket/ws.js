const WebSocket = require('ws');
let latestDataFromPython = {};  // Menyimpan data yang diterima dari Python

function setupWebSocket(server) {
    const wss = new WebSocket.Server({ server });

    wss.on('connection', (ws) => {
        console.log('WebSocket connection established');

        ws.on('message', (message) => {
            const data = JSON.parse(message);
            latestDataFromPython = data;
            console.log('Data received from Python:', latestDataFromPython);
            ws.send(JSON.stringify({ message: 'Data received successfully' }));
        });

        ws.on('close', () => {
            console.log('WebSocket connection closed');
        });
    });

    return wss;
}

// Fungsi untuk mendapatkan data terbaru dari Python
function getLatestData() {
    return Object.keys(latestDataFromPython).length > 0 ? latestDataFromPython : null;
}

module.exports = { setupWebSocket, getLatestData };
