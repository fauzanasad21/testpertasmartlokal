require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: 5432, // Default PostgreSQL port
  max: 300, // Equivalent to connectionLimit in MySQL
  idleTimeoutMillis: 30000, // Optional: idle timeout before a client is closed
  connectionTimeoutMillis: 2000 // Optional: time before a connection attempt times out
});

const dbQuery = async (query, values) => {
  try {
    const results = await pool.query(query, values);
    return results.rows;
  } catch (err) {
    throw err;
  }
};

module.exports = dbQuery;
