const dbQuery = require('../config/db');

const getLimit = async (req, res) => {
  try{
      const query = `
      SELECT * 
      FROM limit_settings
  
    `;
    const result = await dbQuery(query);
    
  
    const results = result.map(item => ({
      data: item.data,
      batasAtas: item.batasAtas,
      batasBawah: item.batasBawah
    }));
  
    res.json(results);
    } catch (err) {
      res.status(500).json({ error: 'Gagal mengambil data' });
    }
}

const setLimit = async (req, res) => {
  const { type, batasAtas, batasBawah } = req.body;


  const allowedtypes = ['temperature', 'pressure', 'flow', 'dryness', 'power_prediction'];
  if (!allowedtypes.includes(type)) {
    return res.status(400).json({ error: 'Tipe sensor tidak valid' });
  }


  if (batasAtas == null || batasBawah == null) {
    return res.status(400).json({ error: 'batasAtas dan batasBawah diperlukan' });
  }

  if (isNaN(batasAtas) || isNaN(batasBawah)) {
    return res.status(400).json({ error: 'batasAtas dan batasBawah harus berupa angka' });
  }


  if (batasAtas <= batasBawah) {
    return res.status(400).json({ error: 'batasAtas harus lebih besar dari batasBawah' });
  }

  try {

    const query = `
      INSERT INTO limit_settings (data, batasAtas, batasBawah)
      VALUES (?, ?, ?)
      ON DUPLICATE KEY UPDATE batasAtas = ?, batasBawah = ?, timestamp = CURRENT_TIMESTAMP
    `;

    const result = await dbQuery(query, [type, batasAtas, batasBawah, batasAtas, batasBawah]);

    res.json({ message: 'Limits saved successfully' });
  } catch (err) {

    res.status(500).json({ error: 'Gagal menyimpan data batas' });
  }
}

const outOfLimit = async (req, res) => {
  const { type, period } = req.query;


  const validTypes = ['flow', 'pressure', 'temperature', 'dryness', 'power'];
  if (!validTypes.includes(type)) {
    return res.status(400).json({ error: 'Invalid type parameter' });
  }


  const limitQuery = `SELECT batasAtas, batasBawah FROM limit_settings WHERE data = ?`;

  try {

    const limits = await dbQuery(limitQuery, [type]);
    if (limits.length === 0) {
      return res.status(404).json({ error: 'No limits found for the given type' });
    }

    const { batasAtas, batasBawah } = limits[0];


    let interval = '';
    switch (period) {
      case 'daily':
        interval = '1 DAY';
        break;
      case 'monthly':
        interval = '30 DAY';
        break;
      case 'yearly':
        interval = '12 MONTH';
        break;
      default:
        return res.status(400).json({ error: 'Invalid period parameter' });
    }


    const query = `
      SELECT COUNT(*) AS count
      FROM real_time_data
      WHERE (${type} < ? OR ${type} > ?)
      AND timestamp >= NOW() - INTERVAL ${interval}
    `;

    const result = await dbQuery(query, [batasBawah, batasAtas]);


    const count = result[0].count;
    const timeExceeded = `${count} hours`;

    res.json({
      type: type,
      timeExceeded: timeExceeded,
      count: count
    });

  } catch (err) {

    console.error(err);
    res.status(500).json({ error: 'Failed to fetch data' });
  }
}

module.exports = { getLimit, setLimit, outOfLimit }