const dbQuery = require('../config/db');
const ss = require('simple-statistics');

function calculateTrend(data) {
  const points = data.map((d, index) => [index, d]);
  const regression = ss.linearRegression(points);
  return regression.m; // Gradient
}

function calculateStatistics(values) {
  const total = values.reduce((sum, value) => sum + value, 0);
  const average = total / values.length;
  const min = Math.min(...values);
  const max = Math.max(...values);

  const variance = values.reduce((variance, value) => variance + Math.pow(value - average, 2), 0) / values.length;
  const stdDeviation = Math.sqrt(variance);
  
  // Calculate trend/gradient
  const gradient = calculateTrend(values);

  return {
    average: average,
    min: min,
    max: max,
    stdDeviation: stdDeviation,
    gradient: gradient
  };
}

const dataGrafik = async (req, res) => {

  const { type, startDate, endDate, page, limit, aggregationInterval } = req.query;

  let column = '';
  switch(type) {
    case 'dryness' : column = 'dryness'; break;
    case 'temperature': column = 'temperature'; break;
    case 'pressure': column = 'pressure'; break;
    case 'flow': column = 'flow'; break;
    case 'power': column = 'power_prediction'; break;
    default: column = 'temperature'; 
  }

  const limitValue = parseInt(limit) || 1000;
  const offset = (parseInt(page) - 1) * limitValue;
  const interval = aggregationInterval || '10m';

  try {
    let query = '';

    if (startDate && endDate) {
      query = `
        SELECT 
          DATE_FORMAT(CONVERT_TZ(timestamp, '+00:00', '+00:00'), '%Y-%m-%d %H:%i:00') AS aggregated_time, 
          AVG(${column}) AS value 
        FROM real_time_data 
        WHERE timestamp BETWEEN ? AND ? 
        GROUP BY aggregated_time 
        ORDER BY aggregated_time ASC
        LIMIT ? OFFSET ?`;

      const result = await dbQuery(query, [startDate, endDate, limitValue, offset]);

      if (result.length > 0) {
        const values = result.map(item => item.value);

        const fullDataQuery = `
          SELECT ${column} AS value 
          FROM real_time_data 
          WHERE timestamp BETWEEN ? AND ?`;
        const fullData = await dbQuery(fullDataQuery, [startDate, endDate]);

        const fullValues = fullData.map(item => item.value);
        const statistics = calculateStatistics(fullValues);

        res.json({
          statistics,
          data: result
        });
      } else {
        res.json({ statistics: {}, data: [] });
      }

    } else {
      query = `SELECT timestamp, ${column} AS value FROM real_time_data 
               ORDER BY timestamp DESC LIMIT ? OFFSET ?`;
      const result = await dbQuery(query, [limitValue, offset]);

      if (result.length > 0) {
        const values = result.map(item => item.value);

        const fullDataQuery = `
          SELECT ${column} AS value 
          FROM real_time_data 
          WHERE timestamp BETWEEN ? AND ?`;
        const fullData = await dbQuery(fullDataQuery, [startDate, endDate]);

        const fullValues = fullData.map(item => item.value);
        const statistics = calculateStatistics(fullValues);

        res.json({
          statistics,
          data: result.reverse()
        });
      } else {
        res.json({ statistics: {}, data: [] });
      }
    }

  } catch (err) {
    res.status(500).json({ error: 'Gagal mengambil data' });
  }
}

module.exports = dataGrafik;
