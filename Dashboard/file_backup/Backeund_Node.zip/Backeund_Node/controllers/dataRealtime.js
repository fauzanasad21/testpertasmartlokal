const { getLatestData } = require('../services_WebSocket/ws');  
const dbQuery = require('../config/db'); 


const dataRealtime = async (req, res) => {
    const latestData = getLatestData();
    if (!latestData) {
        return res.status(404).json({ error: 'Data belum tersedia' });
    }

    try {
        const query = 'SELECT data, batasAtas, batasBawah FROM limit_settings';
        const limits = await dbQuery(query);  

        const period = 'now'
        const queryTrend = `SELECT data_type, gradient FROM statistics_summary WHERE period = '${period}' `
        const trends = await dbQuery(queryTrend);
        const trend_status = {};
        
        trends.forEach(trend => {
            trend_status[trend.data_type] = {
                trendData : trend.gradient,
            }
        })
       
        const limitSettings = {};
        limits.forEach(limit => {
            limitSettings[limit.data] = {
                batasAtas: limit.batasAtas,
                batasBawah: limit.batasBawah
            };
        });


        const checkLimit = (value, limit) => {
            return value > limit.batasAtas || value < limit.batasBawah ? 1 : 0;
        };

        const checktrend = (slope) => {
            if (slope > 0.01) {
                return 'naik';
              } else if (slope < -0.01) {
                return 'turun';
              } else {
                return 'stabil';
              }
        }
        


        const response = {
            flow: {
                data: latestData.flow,
                status: checkLimit(latestData.flow, limitSettings.flow),
                trend: checktrend(trend_status.flow)
            },
            pressure: {
                data: latestData.pressure,
                status: checkLimit(latestData.pressure, limitSettings.pressure),
                trend: checktrend(trend_status.pressure)
            },
            temperature: {
                data: latestData.temperature,
                status: checkLimit(latestData.temperature, limitSettings.temperature),
                trend: checktrend(trend_status.temperature)
            },
            dryness: {
                data: latestData.dryness,
                status: checkLimit(latestData.dryness, limitSettings.dryness),
                trend: checktrend(trend_status.dryness)
            },
            power: {
                data: latestData.power_prediction,
                status: checkLimit(latestData.power_prediction, limitSettings.power_prediction),
                trend: checktrend(trend_status.power_prediction)
            }
        };

        res.status(200).json(response); 
    } catch (err) {
        res.status(500).json({ error: 'Gagal mengambil data' });
    }
};

module.exports = { dataRealtime };
