const dbQuery = require('../config/db');
function convertOutOfLimitCount(outOfLimitCount) {

    const totalSecondsOut = outOfLimitCount * 1;
    const hours = Math.floor(totalSecondsOut / 3600);
    const minutes = Math.floor((totalSecondsOut % 3600) / 60);
    const seconds = totalSecondsOut % 60;
  
    return {
      hours: hours,
      minutes: minutes,
      seconds: seconds
    };
  }
  
  function getTrendStatus(slope) {
    if (slope > 0.01) {
      return 'naik';
    } else if (slope < -0.01) {
      return 'turun';
    } else {
      return 'stabil';
    }
  }

const getStatistics = async (req, res) => {
    let { period, type } = req.query;


    let column = '';
    switch (type) {
      case 'flow':
        column = 'flow';
        break;
      case 'pressure':
        column = 'pressure';
        break;
      case 'temperature':
        column = 'temperature';
        break;
      case 'dryness':
        column = 'dryness';
        break;
      case 'power':
        column = 'power_prediction';
        type = 'power_prediction'
        break;
      default:
        return res.status(400).json({ error: 'Invalid type parameter' });
    }
  

    if (!['now', 'daily', 'monthly', 'yearly'].includes(period)) {
      return res.status(400).json({ error: 'Invalid period parameter' });
    }
  
    try {

      let query = `
        SELECT 
          min_value AS min_${column}, 
          max_value AS max_${column}, 
          avg_value AS avg_${column}, 
          stddev_value AS stddev_${column}, 
          gradient, 
          out_of_limit_count 
        FROM statistics_summary
        WHERE data_type = ? AND period = ?;
      `;
  
  
      const result = await dbQuery(query, [type, period]);
  

      if (result.length === 0) {
        return res.status(404).json({ message: 'No data available' });
      }
      const responseData = result[0];
      const trendStatus = getTrendStatus(responseData.gradient);
      const outOfLimitDuration = convertOutOfLimitCount(responseData.out_of_limit_count);
  

      res.json({
        ...responseData,
        trend_status: trendStatus, 
        out_of_limit_duration: outOfLimitDuration 
      });
  
    } catch (err) {
      console.error('Database query error:', err);
      res.status(500).json({ error: 'Failed to fetch data' });
    }
}

const getGraphStatistics = async (req, res) => {
    const { type, period } = req.query;


    const validTypes = ['flow', 'pressure', 'temperature', 'dryness', 'power'];
    const validPeriods = ['daily', 'monthly', 'yearly'];
  
    if (!validTypes.includes(type)) {
      return res.status(400).json({ error: 'Invalid type parameter' });
    }
  
    if (!validPeriods.includes(period)) {
      return res.status(400).json({ error: 'Invalid period parameter' });
    }
  

    let table = '';
    switch (type) {
      case 'flow': table = 'flow_statistics'; break;
      case 'pressure': table = 'pressure_statistics'; break;
      case 'temperature': table = 'temperature_statistics'; break;
      case 'dryness': table = 'steam_quality_statistics'; break;
      case 'power': table = 'power_prediction_statistics'; break;
    }
  

    const periodCondition = "period_type = ?";  
  
    try {
      const query = `
        SELECT timestamp, min_value, max_value, avg_value, stddev_value 
        FROM ${table} 
        WHERE ${periodCondition}
        ORDER BY timestamp DESC;
      `;
  

      const result = await dbQuery(query, [period]);
      res.json(result);
  
    } catch (err) {
      res.status(500).json({ error: 'Gagal mengambil data' });
    }

}


module.exports = {getStatistics, getGraphStatistics};