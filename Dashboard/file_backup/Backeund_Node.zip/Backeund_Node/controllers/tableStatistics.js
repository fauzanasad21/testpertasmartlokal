const dbQuery = require('../config/db');

const tableStatistics = async (req, res) => {
    const { type, period, page = 1, limit = 10 } = req.query;

    const validTypes = {
      'flow': 'flow_statistics',
      'temperature': 'temperature_statistics',
      'pressure': 'pressure_statistics',
      'dryness': 'steam_quality_statistics',
      'power': 'power_prediction_statistics'
    };
  
    if (!validTypes[type]) {
      return res.status(400).json({ error: 'Tipe data tidak valid' });
    }
  
    const validPeriods = ['daily', 'monthly', 'yearly'];
    if (!validPeriods.includes(period)) {
      return res.status(400).json({ error: 'Period parameter tidak valid, harus daily, monthly, atau yearly' });
    }
  
    const table = validTypes[type];
    const offset = (page - 1) * limit;
  
    const countQuery = `SELECT COUNT(*) as total FROM ${table} WHERE period_type = ?`;
    const dataQuery = `
      SELECT id, 
             timestamp, 
             min_value, 
             max_value, 
             avg_value, 
             stddev_value, 
             period_type
      FROM ${table}
      WHERE period_type = ?
      ORDER BY timestamp DESC
      LIMIT ? OFFSET ?
    `;
  
    try {
      const countResult = await dbQuery(countQuery, [period]);
      const totalRecords = countResult[0].total;
  
      const dataResults = await dbQuery(dataQuery, [period, parseInt(limit), parseInt(offset)]);
  
      if (dataResults.length === 0) {
        return res.status(404).json({ message: 'Tidak ada data ditemukan untuk periode yang dipilih' });
      }
  
      res.json({
        data: dataResults,
        totalRecords: totalRecords,
        currentPage: parseInt(page),
        rowsPerPage: parseInt(limit),
      });
  
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Gagal mengambil data statistik' });
    }
}

const downloadTableStatistics = async (req, res) => {
    const {type,period} = req.query;

    const validTypes = {
      'flow': 'flow_statistics',
      'temperature': 'temperature_statistics',
      'pressure': 'pressure_statistics',
      'dryness': 'steam_quality_statistics',
      'power': 'power_prediction_statistics'
    };
  
    if (!validTypes[type]) {
      return res.status(400).json({ error: 'Tipe data tidak valid' });
    }
  
    const validPeriods = ['daily', 'monthly', 'yearly'];
    if (!validPeriods.includes(period)) {
      return res.status(400).json({ error: 'Period parameter tidak valid, harus daily, monthly, atau yearly' });
    }
  
    const table = validTypes[type];
    try {
      const query = `
      SELECT id, 
             timestamp, 
             min_value, 
             max_value, 
             avg_value, 
             stddev_value, 
             period_type
      FROM ${table}
      WHERE period_type = ?
      ORDER BY timestamp DESC
      `;
      console.log(query)
      const result = await dbQuery(query, [period]);
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: 'Gagal mengambil data' });
    }
}

module.exports = {tableStatistics, downloadTableStatistics }