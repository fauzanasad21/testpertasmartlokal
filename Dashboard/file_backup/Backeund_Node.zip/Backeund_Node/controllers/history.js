const dbQuery = require('../config/db');


const downloadHistory = async (req, res) => {

    const { startDate, endDate } = req.query;
    try {
      const query = `
        SELECT 
          timestamp, 
          flow, 
          pressure, 
          temperature, 
          dryness AS steam_dryness, 
          power_prediction
        FROM real_time_data 
        WHERE timestamp BETWEEN ? AND ?
      `;
      const result = await dbQuery(query, [startDate, endDate]);
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: 'Gagal mengambil data' });
    }
}
const history = async (req, res) => {


    const { startDate, endDate, page = 1 } = req.query;


    const limit = 20;
  
  
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * limit;
  
    try {
  
        const countQuery = `
            SELECT COUNT(*) as totalRecords 
            FROM real_time_data 
            WHERE timestamp BETWEEN ? AND ?;
        `;
        const countResult = await dbQuery(countQuery, [startDate, endDate]);
        const totalRecords = countResult[0].totalRecords;
        const totalPages = Math.ceil(totalRecords / limit);
  
  
        const query = `
            SELECT timestamp, temperature, pressure, flow, dryness, power_prediction 
            FROM real_time_data 
            WHERE timestamp BETWEEN ? AND ? 
            ORDER BY timestamp ASC 
            LIMIT ? OFFSET ?;
        `;
        const result = await dbQuery(query, [startDate, endDate, limit, offset]);

        res.json({
            data: result,
            currentPage: parsedPage,
            totalPages: totalPages,
            totalRecords: totalRecords,
        });
    } catch (err) {
        res.status(500).json({ error: 'Gagal mengambil data' });
    }
}

module.exports = {history, downloadHistory};