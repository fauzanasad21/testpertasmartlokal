const dbQuery = require('../config/db');
const ss = require('simple-statistics');
function calculateTrend(data) {
  const points = data.map((d, index) => [index, d.value]);
  const regression = ss.linearRegression(points);
  return regression.m;
}

function getTrendStatus(slope) {
  if (slope > 0.01) {
    return 'naik';
  } else if (slope < -0.01) {
    return 'turun';
  } else {
    return 'stabil';
  }
}

const trend = async (req, res) => {

  const { type, period } = req.query;

  let column = '';
  switch (type) {
    case 'flow': column = 'flow'; break;
    case 'pressure': column = 'pressure'; break;
    case 'temperature': column = 'temperature'; break;
    case 'dryness': column = 'dryness'; break;
    case 'power': column = 'power_prediction'; break;
    default:
      return res.status(400).json({ error: 'Invalid type parameter' });
  }

  if (period === 'now') {
    try {

      const queryNow = `
          SELECT timestamp, ${column} AS value
          FROM real_time_data
          ORDER BY timestamp DESC
          LIMIT 3600
        `;

      const result = await dbQuery(queryNow);
      if (result.length === 0) {
        return res.status(404).json({ error: 'No data available' });
      }


      const slope = calculateTrend(result);
      const trendStatus = getTrendStatus(slope);

      return res.json({
        trendStatus: trendStatus,
        gradient: slope
      });

    } catch (err) {
      return res.status(500).json({ error: 'Gagal mengambil data' });
    }
  } else {

    let dateFormat = '';
    let limit = 30;
    if (period === 'daily') {
      dateFormat = '%Y-%m-%d';
    } else if (period === 'monthly') {
      dateFormat = '%Y-%m';
      limit = 12;
    } else if (period === 'yearly') {
      dateFormat = '%Y';
      limit = 5;
    } else {
      return res.status(400).json({ error: 'Invalid period parameter' });
    }

    try {

      const query = `
          SELECT DATE_FORMAT(timestamp, '${dateFormat}') AS date, AVG(${column}) AS value
          FROM real_time_data
          GROUP BY date
          ORDER BY date DESC
          LIMIT ${limit}
        `;

      const result = await dbQuery(query);
      if (result.length === 0) {
        return res.status(404).json({ error: 'No data available' });
      }


      const slope = calculateTrend(result);
      const trendStatus = getTrendStatus(slope);

      return res.json({
        trendStatus: trendStatus,
        gradient: slope
      });

    } catch (err) {
      return res.status(500).json({ error: 'Gagal mengambil data' });
    }
  }
}

module.exports = trend;