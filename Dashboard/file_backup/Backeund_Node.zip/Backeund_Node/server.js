const express = require('express');
const http = require('http');
const cookieParser = require('cookie-parser');
require('dotenv').config();
const { setupWebSocket } = require('./services_WebSocket/ws');  
const router = require('./routes/Routes');  
const cors = require('cors');
const redis = require('redis');

const client = redis.createClient();

client.on('error', (err) => {
    console.error('Redis error:', err);
});

client.on('connect', () => {
    console.log('Redis client connected');
});

client.on('ready', () => {
    console.log('Redis client is ready');
});

client.on('end', () => {
    console.log('Redis client disconnected');
});

client.on('reconnecting', (delay, attempt) => {
    console.log(`Redis client attempting to reconnect. Delay: ${delay}ms, Attempt: ${attempt}`);
});


client.connect().then(() => {
    console.log('Redis client connected');
    const app = express();

    app.use(cors({
        origin: 'https://dashboard-agustrisa.as1.pitunnel.net', 
        //origin: 'http://localhost:5173', //dev
        credentials: true,           
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],  
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],  
    }));

    app.use(express.json());
    app.use(cookieParser());


    app.use((req, res, next) => {
        if (!client.isReady) {
            console.error('Redis client is not ready');
            return res.status(500).json({ message: 'Redis client is not ready' });
        }
        req.redisClient = client;  
        
   
        console.log('Redis client added to request:', req.redisClient !== undefined);
    
        next();
    });
    


    app.use('/api', router);

    const server = http.createServer(app);

    setupWebSocket(server);

    const PORT = process.env.PORT || 9921;
    server.listen(PORT, () => {
        console.log(`Server berjalan di http://localhost:${PORT}`);
    });

}).catch((err) => {
    console.error('Gagal terhubung ke Redis:', err);
});