const express = require('express');
const { getCalibration, setCalibration } = require('../controllers/calibration');
const dataGrafik = require('../controllers/dataGrafik');
const { dataRealtime } = require('../controllers/dataRealtime');
const { downloadHistory, history } = require('../controllers/history');
const { getLimit, outOfLimit, setLimit } = require('../controllers/limit');
const NewDataReal = require('../controllers/newDataReal');
const { getStatistics, getGraphStatistics } = require('../controllers/statistics');
const { tableStatistics, downloadTableStatistics } = require('../controllers/tableStatistics');
const trend = require('../controllers/trend');
const { setRegister, setLogin, setLogout } = require('../controllers/auth');
const sendPinToAdmin = require('../middleware/sendmail');
const {authMiddleware, refreshAccessToken} = require('../middleware/authmiddleware');
const { dynamicRateLimiter, incrementAttempts } = require('../middleware/rateLimiter');

const router = express.Router();

router.post('/request-pin', sendPinToAdmin);
router.post('/setLimit', authMiddleware, setLimit);
router.post('/setCalibration', authMiddleware, setCalibration);
router.post('/register', setRegister);
router.post('/login', (req, res, next) => {
    console.log('Login route hit');  // Log ini akan muncul jika rute /login diakses
    next();  // Teruskan ke middleware rate limiter dan setLogin
},  setLogin);
router.post('/refresh-token', refreshAccessToken)

router.post('/logout', authMiddleware, setLogout);

router.get('/check-auth', authMiddleware, (req, res) => {
    res.status(200).json({ message: "Authenticated", userId: req.userId, userName: req.user });
});

router.get('/dataCalibration', authMiddleware, getCalibration);
router.get('/dataGrafik',  dataGrafik)
router.get('/dataRealtime', authMiddleware, dataRealtime);
router.get('/history/all', authMiddleware, downloadHistory);
router.get('/history', authMiddleware, history);
router.get('/getLimit', authMiddleware, getLimit);
router.get('/outOfLimit', authMiddleware, outOfLimit);
router.get('/NewDataReal', authMiddleware, NewDataReal);
router.get('/statistics', authMiddleware, getStatistics);
router.get('/statisticsGraph', authMiddleware, getGraphStatistics);
router.get('/tableStatistics', authMiddleware, tableStatistics);
router.get('/tableStatistics/all', authMiddleware, downloadTableStatistics);
router.get('/trend', authMiddleware, trend);




module.exports = router;